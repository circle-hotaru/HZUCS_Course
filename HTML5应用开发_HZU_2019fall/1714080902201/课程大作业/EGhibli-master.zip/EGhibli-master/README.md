# EGhibli
EGhibli是一个简单的在线展示Ghibli相关资讯平台Demo，项目采用Vue Cli开发

## 技术栈
### 前端技术栈
- Vue
- Vue Router
- Vuex
- vue-aplayer
- Bootstrap
- Jquery

## 快速开始
1. 克隆项目到本地(欢迎star)
2. 安装依赖npm install
3. 启动项目npm run serve

## 页面
- 首页
- 电影
- 人物
- 搜索
- 音乐
- 关于

## 更新记录
### 2019-12-23
因为时间原因，原本计划的前后端项目改为纯前端项目。页面比较简陋，等寒假再更新吧。
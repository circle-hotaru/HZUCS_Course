delete
from system_config
where id = 39;

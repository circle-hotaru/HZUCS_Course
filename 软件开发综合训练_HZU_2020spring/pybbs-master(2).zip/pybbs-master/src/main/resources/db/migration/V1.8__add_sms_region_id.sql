INSERT INTO `system_config` (`id`, `key`, `value`, `description`, `pid`, `type`, `option`, `reboot`)
VALUES
	(58, 'sms_region_id', '', '短信服务所在区域 例如: cn-hangzhou', 49, 'text', NULL, 0);

function suc(msg) {
    layer.msg(msg, {icon: 1, anim: 5, offset: 't'});
}

function err(msg) {
    layer.msg(msg, {icon: 2, anim: 6, offset: 't'});
}

function tip(msg) {
    layer.msg(msg, {offset: 't'});
}

package co.yiiu.pybbs.plugin;

import co.yiiu.pybbs.mapper.OperationLogMapper;
import co.yiiu.pybbs.mapper.TopicMapper;
import co.yiiu.pybbs.model.Comment;
import co.yiiu.pybbs.model.ModelInterface;
import co.yiiu.pybbs.model.OperationLog;
import co.yiiu.pybbs.model.Topic;
import co.yiiu.pybbs.service.impl.CommentService;
import co.yiiu.pybbs.service.impl.TopicService;
import co.yiiu.pybbs.util.Constants;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.PluginUtils;
import com.baomidou.mybatisplus.extension.service.IService;
import net.sf.jsqlparser.statement.select.Top;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.executor.parameter.ParameterHandler;
import org.apache.ibatis.executor.resultset.ResultSetHandler;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.ResultMap;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.Reflector;
import org.apache.ibatis.reflection.SystemMetaObject;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.LocalCacheScope;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import redis.clients.jedis.JedisPool;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.*;

@Intercepts({
//@Signature(type = StatementHandler.class, method = "update", args = {Statement.class}),
        @Signature(type = ParameterHandler.class, method = "setParameters", args = {PreparedStatement.class}),
//        @Signature(type = ResultSetHandler.class, method = "handleResultSets", args = {Statement.class}),
//@Signature(type = StatementHandler.class, method = "batch", args = { Statement.class })
})
@Component
public class UpdateParameterPlugin implements Interceptor, ApplicationContextAware {

    private ApplicationContext applicationContext;

//    JedisPool jedisPool;
//
//    public JedisPool getJedisPool() {
//        return jedisPool;
//    }
//
//    public void setJedisPool(JedisPool jedisPool) {
//        this.jedisPool = jedisPool;
//    }

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        return handlerStatment(invocation);
    }

    private Object handlerStatment(Invocation invocation) throws Throwable {
//        Object[] args = invocation.getArgs();
//        MappedStatement ms = (MappedStatement) args[0];
//        List<ParameterMapping> parameterMappings = ms.getParameterMap().getParameterMappings();
//        if(parameterMappings.isEmpty())
//            return invocation.proceed();
//        if(parameterMappings.get(0).getJavaType() != Topic.class)
//            return invocation.proceed();
//
//        for (ParameterMapping parameterMapping : parameterMappings) {
//            Topic topic = (Topic) parameterMapping.;
//            String upIds = topic.getUpIds();
//            // 如果不修改upIds字段，放行
//            if (StringUtils.isEmpty(upIds))
//                return invocation.proceed();
//            System.out.println("upIds = " + upIds);
//            // 如果想想改数据的upIds字段，则同时修改redis中的upIds
//            String key = Constants.REDIS_GOOD_KEY + topic.getId();
//            jedisPool.getResource().set(key, upIds);
//        }
//
//        StatementHandler statementHandler = (StatementHandler)invocation.getTarget();
//        StatementHandler statementHandler = (StatementHandler) PluginUtils.realTarget(invocation.getTarget());
        ParameterHandler parameterHandler = (ParameterHandler) invocation.getTarget();

        MetaObject metaStatementHandler = SystemMetaObject.forObject(parameterHandler);
//        Reflector forClass = metaStatementHandler.getReflectorFactory().findForClass(MappedStatement.class);
        // 获取redis中反射的类，类似spring的getBean
        MappedStatement mappedStatement = (MappedStatement) metaStatementHandler.getValue("mappedStatement");
        Configuration configuration = (Configuration)metaStatementHandler.getValue("configuration");
//        configuration.setCacheEnabled(false);


//        BeanUtils.copyProperties(mappedStatement1, mappedStatement);
//        configuration.setLocalCacheScope(LocalCacheScope.STATEMENT);

//         如果是select，直接放行
//        if (SqlCommandType.SELECT.equals(mappedStatement.getSqlCommandType())) {
//            return invocation.proceed();
//        }
//        Object parameterObject = statementHandler.getParameterHandler().getParameterObject();
        Object parameterObject = parameterHandler.getParameterObject();
        // 如果是select语句，pass
        if(SqlCommandType.SELECT.equals(mappedStatement.getSqlCommandType())){
            return invocation.proceed();
        }
        else if(SqlCommandType.INSERT.equals(mappedStatement.getSqlCommandType())){
//            new OperationLogHandler<Topic>().handlerOperationLog((Topic)parameterObject,
//                    "插入帖子：", "INSERT");
            if(isClass(parameterObject, Topic.class)){
                new OperationLogHandler<Topic>().handlerOperationLog((Topic)parameterObject,
                    "插入帖子：", "INSERT");
            }else if(isClass(parameterObject, Comment.class)){
                new OperationLogHandler<Comment>().handlerOperationLog((Comment)parameterObject,
                        "插入评论：", "INSERT");
            }
            return invocation.proceed();
        }
        else if(SqlCommandType.DELETE.equals(mappedStatement.getSqlCommandType())){
//            new OperationLogHandler<Topic>().handlerOperationLog((Topic)parameterObject,
//                    "删除帖子：", "DELETE");
            String[] resultSets = mappedStatement.getResultSets();
            if (mappedStatement.getId().equals("co.yiiu.pybbs.mapper.TopicMapper.deleteById")) {
                TopicService bean = applicationContext.getBean(TopicService.class);
                Topic topic = bean.selectById((Integer) parameterObject);
                new OperationLogHandler<Topic>().handlerOperationLog(topic,
                    "删除帖子：", "DELETE");
            }
            else if(mappedStatement.getId().equals("co.yiiu.pybbs.mapper.CommentMapper.deleteById")){
                CommentService bean = applicationContext.getBean(CommentService.class);
                Comment comment = bean.selectById((Integer) parameterObject);
                new OperationLogHandler<Comment>().handlerOperationLog(comment,
                        "删除评论：", "DELETE");
            }
            return invocation.proceed();
        }
        else {


//        MappedStatement mappedStatement1 = new MappedStatement.Builder(configuration, mappedStatement.getId(), mappedStatement.getSqlSource(), mappedStatement.getSqlCommandType())
//                .flushCacheRequired(true).build();
//        metaStatementHandler.setValue("mappedStatement", mappedStatement1);

//        Map<Object, Topic> topics = new HashMap<>();
//        Map<Object, Comment> comments = new HashMap<>();

//        Map map = (Map) parameterObject;
//        String mapKey = "param1";
//        Object et = map.get(mapKey);
//
//        if(!(et instanceof Topic))
//            return invocation.proceed();
//            if(parameterObject instanceof Map){
//               Map map  =(Map)parameterObject;
//               parameterObject = map.get("param1");
//            }

            // 只处理Topic
            if (parameterObject instanceof Topic) {

                Topic topic = (Topic) parameterObject;
                String upIds = topic.getUpIds();
                String redisKey = Constants.REDIS_TOPIC_GOOD_KEY + topic.getId();
//                topicOperationLog(parameterObject, "更新帖子为：", "UPDATE");
                new OperationLogHandler<Topic>().handlerOperationLog(topic, "更新帖子为：", "UPDATE");
                RedisService redisService = applicationContext.getBean(RedisService.class);
                if(upIds == null)
                    upIds = "";
                redisService.setStringPersistent(redisKey, upIds);
//                configuration.getCaches().clear();
//            jedisPool.getResource().set(redisKey, upIds);
            }
            // 处理Comment
            else if (parameterObject instanceof Comment) {
                Comment comment = (Comment) parameterObject;
                String upIds = comment.getUpIds();
                String redisKey = Constants.REDIS_COMMENT_GOOD_KEY + comment.getId();
                new OperationLogHandler<Comment>().handlerOperationLog(comment, "更新评论为：", "UPDATE");
                RedisService redisService = applicationContext.getBean(RedisService.class);
                if(upIds == null)
                    upIds = "";
                redisService.setStringPersistent(redisKey, upIds);
            }
        }
//        topic.setUpIds(null);
//        map.replace(mapKey, topic);
//        map.forEach((key, item)-> {
//            if(item instanceof Topic){
//                topics.put(key, (Topic)item);
//            }
//            else if(item instanceof Comment){
//                comments.put(key, (Comment)item);
//            }
//        });

//        for (Map.Entry<Object, Topic> topic : topics.entrySet()) {
//            String upIds = topic.getValue().getUpIds();
//            // 如果想想改数据的upIds字段，则同时修改redis中的upIds
//            String key = Constants.REDIS_TOPIC_GOOD_KEY + topic.getValue().getId();
//            if(upIds == null)
//                return invocation.proceed();
//            String str = upIds;
//            if(topic.getKey().equals("et")){
//                jedisPool.getResource().set(key, str);
//            }
//            // 把upids数值置为null，代表不写入mysql
//            // 设置两个值，防止sql读缓存
//            if(topic.getValue().getUpIds().equals("1"))
//                topic.getValue().setUpIds("2");
//            else
//                topic.getValue().setUpIds("1");
//            map.replace(key, topic.getValue());
////            Map arg = (Map) invocation.getArgs()[0];
////            PreparedStatement preparedStatement = (PreparedStatement) invocation.getArgs()[0];
////            parameterHandler.setParameters(preparedStatement);
////            statementHandler.getParameterHandler().setParameters(preparedStatement);
////            Field[] declaredFields = parameterObject.getClass().getDeclaredFields();
//
//        }

//        for (Map.Entry<Object, Comment> comment : comments.entrySet()) {
//            String upIds = comment.getValue().getUpIds();
//            // 如果不修改upIds字段，放行
//            if (StringUtils.isEmpty(upIds))
//                return invocation.proceed();
//            // 如果想想改数据的upIds字段，则同时修改redis中的upIds
//            String key = Constants.REDIS_COMMENT_GOOD_KEY + comment.getValue().getId();
//            jedisPool.getResource().set(key, upIds);
//            // 把upids数值置为null，代表不写入mysql
////            comment.getValue().setUpIds(null);
////            map.replace(key, comment.getValue());
////            PreparedStatement preparedStatement = (PreparedStatement) map;
////            statementHandler.getParameterHandler().setParameters(preparedStatement);
//        }


        return invocation.proceed();
    }

    private boolean isClass(Object parameterObject, Class cls){
        if(parameterObject.getClass() == cls){
            return true;
        }
        else if(parameterObject instanceof Map){
            Map map = (Map)parameterObject;
            Object param1 = map.get("param1");
            if(param1 == null)
                return false;
            else if(param1.getClass() == cls)
                return true;
        }
        return false;
    }

//    private void topicOperationLog(Object parameterObject, String prefix, String type) {
//        if(parameterObject instanceof Topic){
//            subTopicOperationLog(parameterObject, prefix, type);
//        }else if (parameterObject instanceof Map) {
//            Map map = (Map) parameterObject;
//            Object param1 = map.get("param1");
//            if (param1 instanceof Topic) {
//                subTopicOperationLog(parameterObject, prefix, type);
//            }
////                Topic topic = (Topic) param1;
////                OperationLogMapper logMapper = applicationContext.getBean(OperationLogMapper.class);
////                OperationLog operationLog = new OperationLog();
////                // 默认操作都是作者做的，如果是管理员，那gg；
////                String content = prefix;
////                if(type.equals("UPDATE")){
////                    TopicService topicService = applicationContext.getBean(TopicService.class);
////                    Topic oldTopic = topicService.selectById(topic.getId());
////                    content += ("---->" + oldTopic);
////                }
////                operationLog.setUid(topic.getUserId());
////                operationLog.setInTime(new Date());
////                operationLog.setContent(content + topic.toString());
////                operationLog.setType(type);
////                logMapper.insert(operationLog);
////            }
//        }
//    }

//    private void subTopicOperationLog(Object parameterObject, String prefix, String type){
//        Topic topic = (Topic) parameterObject;
//        OperationLogMapper logMapper = applicationContext.getBean(OperationLogMapper.class);
//        OperationLog operationLog = new OperationLog();
//        // 默认操作都是作者做的，如果是管理员，那gg；
//        String content = prefix;
//        if(type.equals("UPDATE")){
//            TopicMapper topicMapper = applicationContext.getBean(TopicMapper.class);
//            Topic oldTopic = topicMapper.selectById(topic.getId());
////            TopicService topicService = applicationContext.getBean(TopicService.class);
////            Topic oldTopic = topicService.selectById(topic.getId());
//            content += ( oldTopic + "\n---->\n");
//        }
//        content += topic.toString();
//        System.out.println("content = " + content);
//        operationLog.setContent(content);
//        operationLog.setUid(topic.getUserId());
//        operationLog.setInTime(new Date());
//        operationLog.setType(type);
//        logMapper.insert(operationLog);
//    }

//    private void subCommentOperationLog(Object parameterObject, String prefix, String type){
//        Comment comment = (Comment) parameterObject;
//        OperationLogMapper logMapper = applicationContext.getBean(OperationLogMapper.class);
//        OperationLog operationLog = new OperationLog();
//        // 默认操作都是作者做的，如果是管理员，那gg；
//        String content = prefix;
//        if(type.equals("UPDATE")){
//            CommentService commentService = applicationContext.getBean(CommentService.class);
//            Comment oldComment = commentService.selectById(comment.getId());
////            TopicService topicService = applicationContext.getBean(TopicService.class);
////            Topic oldTopic = topicService.selectById(topic.getId());
//            content += ( oldComment + "\n---->\n");
//        }
//        content += comment.toString();
//        System.out.println("content = " + content);
//        operationLog.setContent(content);
//        operationLog.setUid(comment.getUserId());
//        operationLog.setInTime(new Date());
//        operationLog.setType(type);
//        logMapper.insert(operationLog);
//    }


    class OperationLogHandler<T>{
        private void handlerOperationLog(T newObj, String prefix, String type) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

            OperationLogMapper logMapper = applicationContext.getBean(OperationLogMapper.class);

//            ModelInterface modelInterface = (ModelInterface) newObj;
            OperationLog operationLog = new OperationLog();
            // 默认操作都是作者做的，如果是管理员，那gg；
            // content格式：更新为：old ----> newObj。 插入了：newObj。 删除了：newObj。
            String content = prefix;
            if(type.equals("UPDATE")) {
                char[] preStr = newObj.getClass().getSimpleName().toCharArray();
                // 将类名第一个字母改为小写。
                preStr[0] -= ('A' - 'a');
                // 构造出beanName
                String serviceName = String.valueOf(preStr) + "Service";
                Object bean = applicationContext.getBean(serviceName);
//                BaseMapper mapper = (BaseMapper) bean;
//                Object old = mapper.selectById(modelInterface.getId());
                Class<?> beanClass = bean.getClass();
                Method method = beanClass.getDeclaredMethod("selectById", Integer.class);
                // 执行model对象的getId()方法。
                Method getIdMethod = newObj.getClass().getMethod("getId");
                Integer id = (Integer)getIdMethod.invoke(newObj);

                // 执行Service对象的selectById方法;
                Object old = method.invoke(bean, id);
//                Method method = beanClass.getDeclaredMethod("selectById");
//                Object old = method.invoke(modelInterface.getId());
                content += ( old + "\n---->\n");
            }
            // 增删改的日志最后都要加上新对象
            content += newObj;
            // 获取并执行getUserId方法
            Method getUserIdMethod = newObj.getClass().getMethod("getUserId");
            Integer userId = (Integer)getUserIdMethod.invoke(newObj);
            operationLog.setType(type);
            operationLog.setContent(content);
            operationLog.setUid(userId);
            operationLog.setInTime(new Date());
            logMapper.insert(operationLog);
        }
    }

    @Override
    public Object plugin(Object o) {
//        System.out.println("o = " + o);
        return Plugin.wrap(o, this);
//        return new Object();
    }

    @Override
    public void setProperties(Properties properties) {

    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

}
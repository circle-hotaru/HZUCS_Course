package co.yiiu.pybbs.service;

import co.yiiu.pybbs.model.OperationLog;
import co.yiiu.pybbs.service.impl.OperationService;

import java.util.List;

public interface IOperationService {
    void insert(OperationLog operationLog);
    void deleteById(Integer id);
    OperationLog selectById(Integer id);
    List<OperationLog> selectByUserId(Integer userId);
    List<OperationLog> selectAll();
}

package co.yiiu.pybbs.plugin;

import co.yiiu.pybbs.model.Comment;
import co.yiiu.pybbs.model.Topic;
import co.yiiu.pybbs.plugin.RedisService;
import co.yiiu.pybbs.util.Constants;
import co.yiiu.pybbs.util.StringUtil;
import com.baomidou.mybatisplus.core.toolkit.PluginUtils;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import net.sf.jsqlparser.statement.select.Top;
import org.apache.ibatis.cursor.Cursor;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.executor.resultset.DefaultResultSetHandler;
import org.apache.ibatis.executor.resultset.ResultSetHandler;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.ParameterMapping;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.SystemMetaObject;
import org.apache.ibatis.session.ResultHandler;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import redis.clients.jedis.JedisPool;

import java.lang.reflect.InvocationTargetException;
import java.sql.Array;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

@Intercepts({
//@Signature(type = StatementHandler.class, method = "query", args = {Statement.class, ResultHandler.class}),
@Signature(type = ResultSetHandler.class, method = "handleResultSets", args = {Statement.class}),
//@Signature(type = StatementHandler.class, method = "batch", args = { Statement.class })
})
@Component
public class SelectResultSetPlugin implements Interceptor, ApplicationContextAware {

//    JedisPool jedisPool;
    private ApplicationContext applicationContext;

//    public JedisPool getJedisPool() {
//        return jedisPool;
//    }
//
//    public void setJedisPool(JedisPool jedisPool) {
//        this.jedisPool = jedisPool;
//    }

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        return handlerResult(invocation);
    }

    private Object handlerStatment(Invocation invocation) throws Throwable {
//        Object[] args = invocation.getArgs();
//        MappedStatement ms = (MappedStatement) args[0];
//        List<ParameterMapping> parameterMappings = ms.getParameterMap().getParameterMappings();
//        if(parameterMappings.isEmpty())
//            return invocation.proceed();
//        if(parameterMappings.get(0).getJavaType() != Topic.class)
//            return invocation.proceed();
//
//        for (ParameterMapping parameterMapping : parameterMappings) {
//            Topic topic = (Topic) parameterMapping.;
//            String upIds = topic.getUpIds();
//            // 如果不修改upIds字段，放行
//            if (StringUtils.isEmpty(upIds))
//                return invocation.proceed();
//            System.out.println("upIds = " + upIds);
//            // 如果想想改数据的upIds字段，则同时修改redis中的upIds
//            String key = Constants.REDIS_GOOD_KEY + topic.getId();
//            jedisPool.getResource().set(key, upIds);
//        }
//
////        StatementHandler statementHandler = (StatementHandler)invocation.getTarget();
////        StatementHandler statementHandler = (StatementHandler) PluginUtils.realTarget(invocation.getTarget());
////        MetaObject metaStatementHandler = SystemMetaObject.forObject(statementHandler);
////        metaStatementHandler.
////        MappedStatement mappedStatement = (MappedStatement) metaStatementHandler.getValue("delegate.mappedStatement");
//        // 如果是select，直接放行
////        if (SqlCommandType.SELECT.equals(mappedStatement.getSqlCommandType())) {
////            return invocation.proceed();
////        }
////        Object parameterObject = statementHandler.getParameterHandler().getParameterObject();
//        if(parameterObject instanceof Topic){
//            Topic topic = (Topic) parameterObject;
//            String upIds = topic.getUpIds();
//            // 如果不修改upIds字段，放行
//            if (StringUtils.isEmpty(upIds))
//                return invocation.proceed();
//            System.out.println("upIds = " + upIds);
//            // 如果想想改数据的upIds字段，则同时修改redis中的upIds
//            String key = Constants.REDIS_GOOD_KEY + topic.getId();
//            jedisPool.getResource().set(key, upIds);
//        }

        return invocation.proceed();
    }

    private Object handlerResult(Invocation invocation) throws Throwable {
        Object result = invocation.proceed();
        if (result instanceof ArrayList) {
            ArrayList resultList = (ArrayList) result;
            if (resultList.size() == 0)
                return result;

            if (resultList.get(0) instanceof Topic) {

                for (int i = 0; i < resultList.size(); i++) {

                    //依次获取其中的对象
                    Object object = resultList.get(i);
                    //利用反射对结果集中的每个对象进行处理，
//                handleObject(object);
//                System.out.println(object);
                    Topic topic = (Topic) object;
                    RedisService redisService = applicationContext.getBean(RedisService.class);
                    if(redisService.instance() == null){
                        return result;
                    }
                    String good = redisService.getString(Constants.REDIS_TOPIC_GOOD_KEY + topic.getId());
//                    String good = jedisPool.getResource().get(Constants.REDIS_TOPIC_GOOD_KEY + topic.getId());
                    // 如果redis没有配置，直接返回
                    topic.setUpIds(good);
                    resultList.set(i, (Object) topic);
                }
                return resultList;
            }
            else if(resultList.get(0) instanceof Comment){
                for (int i = 0; i < resultList.size(); i++) {
                    //依次获取其中的对象
                    Object object = resultList.get(i);
                    Comment comment = (Comment) object;
                    // 评论点赞
                    RedisService redisService = applicationContext.getBean(RedisService.class);
                    String good = redisService.getString(Constants.REDIS_COMMENT_GOOD_KEY + comment.getId());
//                    String good = jedisPool.getResource().get(Constants.REDIS_COMMENT_GOOD_KEY + comment.getId());
                    comment.setUpIds(good);
                    resultList.set(i, (Object) comment);
                }
                return resultList;
            }
        }
        return result;
    }

    @Override
    public Object plugin(Object o) {
//        System.out.println("o = " + o);
        return Plugin.wrap(o, this);
    }

    @Override
    public void setProperties(Properties properties) {

    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}
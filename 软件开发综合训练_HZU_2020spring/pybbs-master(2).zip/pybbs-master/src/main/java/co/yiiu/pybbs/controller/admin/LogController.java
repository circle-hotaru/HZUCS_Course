package co.yiiu.pybbs.controller.admin;

import co.yiiu.pybbs.controller.api.BaseApiController;
import co.yiiu.pybbs.model.OperationLog;
import co.yiiu.pybbs.model.UserLoginLog;
import co.yiiu.pybbs.service.IOperationService;
import co.yiiu.pybbs.service.IUserLoginLogService;
import co.yiiu.pybbs.service.impl.OperationService;
import co.yiiu.pybbs.service.impl.UserLoginLogService;
import co.yiiu.pybbs.util.Result;
import org.apache.shiro.authz.annotation.RequiresAuthentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/log")
public class LogController extends BaseApiController {

    @Autowired
    IUserLoginLogService userLoginLogService;

    @Autowired
    IOperationService operationService;

    @RequiresAuthentication
    @GetMapping("/api/userlog")
    public Result getUserLogAPI(){
        List<UserLoginLog> userLoginLogs = userLoginLogService.selectAll();
        return success(userLoginLogs);
    }

    @RequiresAuthentication
    @GetMapping("/userlog")
    public String getUserLog(){
        return "/log/userlog";
    }

    @RequiresAuthentication
    @GetMapping("/api/userlog/user/{userId}")
    public Result getUserLogByUser(@PathVariable Integer userId){
        List<UserLoginLog> userLoginLogs = userLoginLogService.selectByUserId(userId);
        return success(userLoginLogs);
    }

    @RequiresAuthentication
    @GetMapping("/api/userlog/{id}")
    public Result getUserLogById(@PathVariable Integer id){
        return success(userLoginLogService.selectById(id));
    }

    @RequiresAuthentication
    @GetMapping("/api/userlog/user/end")
    public Result getUserEnd(){
        List<UserLoginLog> userLoginLogs = userLoginLogService.selectAllUserEnd();
        return success(userLoginLogs);
    }

    @RequiresAuthentication
    @GetMapping("/operation")
    public String getAllOperationLog(){
        return "/log/operation";
    }

    @RequiresAuthentication
    @GetMapping("/api/operation")
    public Result getAllOperationLogAPI(){
        List<OperationLog> operationLogs = operationService.selectAll();
        return success(operationLogs);
    }

    @RequiresAuthentication
    @GetMapping("/api/operation/{id}")
    public Result getOperationLog(@PathVariable Integer id){
        return success(operationService.selectById(id));
    }
}

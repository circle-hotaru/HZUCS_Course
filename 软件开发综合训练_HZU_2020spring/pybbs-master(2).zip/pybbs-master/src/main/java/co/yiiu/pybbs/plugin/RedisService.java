package co.yiiu.pybbs.plugin;

import co.yiiu.pybbs.config.service.BaseService;
import co.yiiu.pybbs.model.SystemConfig;
import co.yiiu.pybbs.service.ISystemConfigService;
import com.alibaba.fastjson.JSON;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.params.SetParams;
import java.lang.Object;

import java.io.*;
import java.util.HashSet;
import java.util.Set;


@Component
@DependsOn("mybatisPlusConfig")
public class RedisService implements BaseService<JedisPool> {

    @Autowired
    private ISystemConfigService systemConfigService;
    private JedisPool jedisPool;
    private Logger log = LoggerFactory.getLogger(RedisService.class);

//    @Autowired
//    @Lazy
//    MyPlugin myPlugin;
//
//    @Autowired
//    @Lazy
//    BBSStatementPlugin bbsStatementPlugin;
//
//    @Autowired
//    @Lazy
//    UpdateStatmentPlugin updateStatmentPlugin;

    public void setJedis(JedisPool jedisPool) {
        this.jedisPool = jedisPool;
    }

    public void flush(){
        Jedis jedis = getJedis();
        if(jedis != null){
            jedis.flushAll();
        }
    }

    public void setInstanceNull(){
        jedisPool = null;
    }

    public JedisPool instance() {
        try {
            if (this.jedisPool != null) return this.jedisPool;
            // 获取redis的连接
            // host
            SystemConfig systemConfigHost = systemConfigService.selectByKey("redis_host");
            String host = systemConfigHost.getValue();
            // port
            SystemConfig systemConfigPort = systemConfigService.selectByKey("redis_port");
            String port = systemConfigPort.getValue();
            // password
            SystemConfig systemConfigPassword = systemConfigService.selectByKey("redis_password");
            String password = systemConfigPassword.getValue();
            password = StringUtils.isEmpty(password) ? null : password;
            // database
            SystemConfig systemConfigDatabase = systemConfigService.selectByKey("redis_database");
            String database = systemConfigDatabase.getValue();
            // timeout
            SystemConfig systemConfigTimeout = systemConfigService.selectByKey("redis_timeout");
            String timeout = systemConfigTimeout.getValue();

            if (!this.isRedisConfig()) {
                log.info("redis配置信息不全或没有配置...");
                return null;
            }
            JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
            // 配置jedis连接池最多空闲多少个实例，源码默认 8
            jedisPoolConfig.setMaxIdle(7);
            // 配置jedis连接池最多创建多少个实例，源码默认 8
            jedisPoolConfig.setMaxTotal(20);
            //在borrow(引入)一个jedis实例时，是否提前进行validate操作；如果为true，则得到的jedis实例均是可用的；
            jedisPoolConfig.setTestOnBorrow(true);
            //return 一个jedis实例给pool时，是否检查连接可用性（ping()）
            jedisPoolConfig.setTestOnReturn(true);
            jedisPool = new JedisPool(jedisPoolConfig, host, Integer.parseInt(port), Integer.parseInt(timeout), password,
                    Integer.parseInt(database));
            log.info("redis连接对象获取成功...");

            //----------------------设置几个需要持久化字段的mybatis插件-------------
//            myPlugin.setJedisPool(jedisPool);
//            bbsStatementPlugin.setJedisPool(jedisPool);
//            updateStatmentPlugin.setJedisPool(jedisPool);
            return this.jedisPool;
        } catch (Exception e) {
            log.error("配置redis连接池报错，错误信息: {}", e.getMessage());
            return null;
        }
    }

    // 判断redis是否配置了
    public boolean isRedisConfig() {
        SystemConfig systemConfigHost = systemConfigService.selectByKey("redis_host");
        String host = systemConfigHost.getValue();
        // port
        SystemConfig systemConfigPort = systemConfigService.selectByKey("redis_port");
        String port = systemConfigPort.getValue();
        // database
        SystemConfig systemConfigDatabase = systemConfigService.selectByKey("redis_database");
        String database = systemConfigDatabase.getValue();
        // timeout
        SystemConfig systemConfigTimeout = systemConfigService.selectByKey("redis_timeout");
        String timeout = systemConfigTimeout.getValue();

        return !StringUtils.isEmpty(host) && !StringUtils.isEmpty(port) && !StringUtils.isEmpty(database) && !StringUtils
                .isEmpty(timeout);
    }

    // 获取String值
    public String getString(String key) {
//        JedisPool instance = this.instance();
        if (StringUtils.isEmpty(key)) return null;
        Jedis jedis = getJedis();
        if (jedis == null) return null;
        String value = jedis.get(key);
        jedis.close();
        return value;
    }

    public void setStringPersistent(String key, String value) {
//        JedisPool instance = this.instance();
        if (StringUtils.isEmpty(key)) return;
//        Jedis jedis = instance.getResource();
        Jedis jedis = getJedis();
        if (jedis == null) return;
        jedis.set(key, value);
        jedis.close();
    }


    public void setString(String key, String value) {
        this.setString(key, value, 300); // 如果不指定过时时间，默认为5分钟
    }

    /**
     * 带有过期时间的保存数据到redis，到期自动删除
     *
     * @param key
     * @param value
     * @param expireTime 单位 秒
     */
    public void setString(String key, String value, int expireTime) {
        if (StringUtils.isEmpty(key) || StringUtils.isEmpty(value)) return;
        Jedis jedis = getJedis();
        if (jedis == null) return;
        SetParams params = new SetParams();
        params.px(expireTime * 1000);
        jedis.set(key, value, params);
        jedis.close();
    }

    public void delString(String key) {
        if (StringUtils.isEmpty(key)) return;
        Jedis jedis = getJedis();
        if (jedis == null) return;
        jedis.del(key); // 返回值成功是 1
        jedis.close();
    }

    public void addSet(String key, Object object){
        if(StringUtils.isEmpty(key) || object == null) return;
        Jedis jedis = getJedis();
        if (jedis == null) return;
        jedis.sadd(key, jsonSerialize(object));

    }

    // 获取集合的全部成员
    public Set<Object> getSet(String key ){
        HashSet<Object> result = new HashSet<>();
        if (StringUtils.isEmpty(key)) return null;
        Jedis jedis = getJedis();
        if (jedis == null) return null;

        // 将对象遍历并反序列化
        jedis.smembers(key).forEach((item) ->{
            result.add(jsonUnSerialize(item));
        });
         return result;
    }

    // 判断是否是集合的成员
    public boolean isExistSet(String key, Object object){
        if (StringUtils.isEmpty(key)) return false;
        Jedis jedis = getJedis();
        if(jedis == null) return false;

        return jedis.sismember(key, jsonSerialize(object));
    }

    // 在集合中删除
    public void remSet(String key, Object object){

        if(StringUtils.isEmpty(key) || object == null) return;
        Jedis jedis = getJedis();
        if(jedis == null) return;

        jedis.srem(key, jsonSerialize(object));
    }

    public int SetSize(String key){
        if(StringUtils.isEmpty(key)) return 0;
        Jedis jedis = getJedis();
        if(jedis == null) return 0;
        return jedis.scard(key).intValue();
    }

    // 序列化
    private static byte[] serialize(Object object) {
        ObjectOutputStream objectOutputStream = null;
        ByteArrayOutputStream byteArrayOutputStream = null;
        try {
            byteArrayOutputStream = new ByteArrayOutputStream();
            objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
            objectOutputStream.writeObject(object);
            byte[] getByte = byteArrayOutputStream.toByteArray();
            return getByte;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    // 反序列化
    private static Object unserizlize(byte[] binaryByte) {
        ObjectInputStream objectInputStream = null;
        ByteArrayInputStream byteArrayInputStream = null;
        byteArrayInputStream = new ByteArrayInputStream(binaryByte);
        try {
            objectInputStream = new ObjectInputStream(byteArrayInputStream);
            Object obj = objectInputStream.readObject();
            return obj;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String jsonSerialize(Object object){
        System.out.println("object = " + object);
        return JSON.toJSONString(object);
    }

    private static Object jsonUnSerialize(String str){
        System.out.println("str = " + str);
        return JSON.parseObject(str);
    }


    public Jedis getJedis(){
        JedisPool instance = this.instance();
        Jedis jedis;
        if (instance == null) return null;
        try {
            jedis = instance.getResource();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return jedis;
    };

    // TODO 后面有需要会补充获取 list, map 等方法

}

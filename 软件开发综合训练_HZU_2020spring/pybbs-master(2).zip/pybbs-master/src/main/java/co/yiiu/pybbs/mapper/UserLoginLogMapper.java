package co.yiiu.pybbs.mapper;

import co.yiiu.pybbs.model.UserLoginLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface UserLoginLogMapper extends BaseMapper<UserLoginLog> {
}

package co.yiiu.pybbs.controller.admin;

import co.yiiu.pybbs.config.FlywayConfig;
import co.yiiu.pybbs.plugin.RedisService;
import co.yiiu.pybbs.service.ISystemConfigService;
import co.yiiu.pybbs.util.Result;
import org.apache.commons.logging.LogFactory;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.checkerframework.checker.units.qual.A;
import org.flywaydb.core.Flyway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/admin/system")
@DependsOn("mybatisPlusConfig")
public class SystemConfigAdminController extends BaseAdminController {

    private Logger log = LoggerFactory.getLogger(SystemConfigAdminController.class);
    @Autowired
    private ISystemConfigService systemConfigService;

    @Autowired
    FlywayConfig flywayConfig;

    @Autowired
    RedisService redisService;

    @RequiresPermissions("system:edit")
    @ResponseBody
    @GetMapping("/init")
    public Result init(HttpServletRequest request) {
//        Flyway flyway = flywayConfig
//                .getDataSource()
//                .baselineOnMigrate(true)
//                .load();

        if(redisService != null){
            log.info("redis正在初始化");
            redisService.flush();
            log.info("redis初始化成功");
            redisService.setInstanceNull();
        }
        Flyway flyway = flywayConfig.getFlyway();
        log.info("正在清空数据库");
        flyway.clean();
        log.info("正在进行数据库初始化");
        flyway.migrate();
        log.info("数据库初始化成功");
        request.getSession().removeAttribute("_user");
        return success();
    }

    @RequiresPermissions("system:edit")
    @GetMapping("/edit")
    public String edit(Model model) {
        model.addAttribute("systems", systemConfigService.selectAll());
        return "admin/system/edit";
    }

    @RequiresPermissions("system:edit")
    @PostMapping("/edit")
    @ResponseBody
    public Result edit(@RequestBody List<Map<String, String>> list) {
        systemConfigService.update(list);
        return success();
    }
}

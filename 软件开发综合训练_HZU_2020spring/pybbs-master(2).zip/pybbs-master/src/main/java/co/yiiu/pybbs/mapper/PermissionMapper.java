package co.yiiu.pybbs.mapper;

import co.yiiu.pybbs.model.Permission;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * Created by tomoya.
 * Copyright (c) 2018, All Rights Reserved.
 * https://yiiu.co
 */
public interface PermissionMapper extends BaseMapper<Permission> {
}

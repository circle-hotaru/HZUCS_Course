package co.yiiu.pybbs.util;

/**
 * Created by tomoya.
 * Copyright (c) 2018, All Rights Reserved.
 * https://yiiu.co
 */
public class Constants {

    private Constants() {
    }

    public static final String REDIS_SYSTEM_CONFIG_KEY = "dhbbs_system_config";

    public static final String REDIS_TOPIC_KEY = "dhbbs_topic_"; // 后面还要拼上话题的id

    public static final String REDIS_FOLLOWER_KEY = "dhbbs_follow_";// 后面还要拼上用户的id

    public static final String REDIS_FUNS_KEY = "dhbbs_funs_";// 后面还要拼上用户的id

    public static final String REDIS_TOPIC_GOOD_KEY = "dhbbs_topic_good_";// 后面还要拼上用户的id

    public static final String REDIS_COMMENT_GOOD_KEY = "dhbbs_comment_good_";
}

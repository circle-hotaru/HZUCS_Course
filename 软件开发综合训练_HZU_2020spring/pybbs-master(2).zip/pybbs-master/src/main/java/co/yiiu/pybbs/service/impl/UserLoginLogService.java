package co.yiiu.pybbs.service.impl;

import co.yiiu.pybbs.mapper.UserLoginLogMapper;
import co.yiiu.pybbs.model.UserLoginLog;
import co.yiiu.pybbs.service.IUserLoginLogService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserLoginLogService implements IUserLoginLogService {

    @Autowired
    UserLoginLogMapper userLoginLogMapper;

    @Override
    public void insert(UserLoginLog userLoginLog) {
        userLoginLogMapper.insert(userLoginLog);
    }

    @Override
    public void deleteById(Integer id) {
        userLoginLogMapper.deleteById(id);
    }

    @Override
    public UserLoginLog selectById(Integer id) {
        return userLoginLogMapper.selectById(id);
    }

    @Override
    public List<UserLoginLog> selectByUserId(Integer uid) {

        return userLoginLogMapper.selectList(new QueryWrapper<UserLoginLog>().eq("uid", uid));
    }

    @Override
    public UserLoginLog selectEndOne(Integer uid) {
        return userLoginLogMapper.selectOne(new QueryWrapper<UserLoginLog>()
                .eq("uid", uid)
                .orderByDesc("log_id")
                .last("limit 1")
        );
    }

    @Override
    public UserLoginLog updateEndOne(UserLoginLog userLoginLog) {
//        return userLoginLogMapper.update(userLoginLog,new UpdateWrapper<UserLoginLog>()
//                .set("logout_time", userLoginLog.getLogoutTime()
//                ).inSql("uid", "select ")
//        );
        return new UserLoginLog();
    }

    @Override
    public List<UserLoginLog> selectAllUserEnd() {
        return userLoginLogMapper.selectList(new QueryWrapper<UserLoginLog>()
                .inSql("log_id", "select max(log_id) \n" +
                        "from user_login_log \n" +
                        "group by uid")
        );

    }

    @Override
    public List<UserLoginLog> selectAll() {
        return userLoginLogMapper.selectList(new QueryWrapper<UserLoginLog>());
    }

}

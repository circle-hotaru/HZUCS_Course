package co.yiiu.pybbs.plugin;


import co.yiiu.pybbs.model.Comment;
import co.yiiu.pybbs.model.Topic;
import co.yiiu.pybbs.util.Constants;
import com.baomidou.mybatisplus.core.toolkit.PluginUtils;
import net.sf.jsqlparser.statement.select.Top;
import org.apache.ibatis.executor.parameter.ParameterHandler;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.reflection.MetaObject;
import org.apache.ibatis.reflection.SystemMetaObject;
import org.springframework.stereotype.Component;
import redis.clients.jedis.JedisPool;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

@Intercepts({
@Signature(type = StatementHandler.class, method = "update", args = {Statement.class}),
//        @Signature(type = StatementHandler.class, method = "setParameters", args = {PreparedStatement.class}),
//        @Signature(type = ResultSetHandler.class, method = "handleResultSets", args = {Statement.class}),
//@Signature(type = StatementHandler.class, method = "batch", args = { Statement.class })
})
@Component
public class UpdateStatmentPlugin implements Interceptor {

    JedisPool jedisPool;

    public JedisPool getJedisPool() {
        return jedisPool;
    }

    public void setJedisPool(JedisPool jedisPool) {
        this.jedisPool = jedisPool;
    }

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        StatementHandler statementHandler = (StatementHandler) PluginUtils.realTarget(invocation.getTarget());
        MetaObject metaStatementHandler = SystemMetaObject.forObject(statementHandler);
        MappedStatement mappedStatement = (MappedStatement) metaStatementHandler.getValue("delegate.mappedStatement");
//         如果是select，直接放行
        if (SqlCommandType.SELECT.equals(mappedStatement.getSqlCommandType())) {
            return invocation.proceed();
        }
        Object parameterObject = statementHandler.getParameterHandler().getParameterObject();
        if(!(parameterObject instanceof Map))
            return invocation.proceed();
        invocation.proceed();
//        Map<Object, Topic> topics = new HashMap<>();
//        Map<Object, Comment> comments = new HashMap<>();
//
//        Map map = (Map) parameterObject;
//
//        Object et = map.get("et");
//        Topic topic;
//        if(et instanceof Topic)
//            topic = (Topic)et;

//        map.forEach((key, item)-> {
//            if(item instanceof Topic){
//                topics.put(key, (Topic)item);
//            }
//            else if(item instanceof Comment){
//                comments.put(key, (Comment)item);
//            }
//        });

//        for (Map.Entry<Object, Topic> topic : topics.entrySet()) {
//            String upIds = topic.getValue().getUpIds();
//            // 如果想想改数据的upIds字段，则同时修改redis中的upIds
//            String key = Constants.REDIS_TOPIC_GOOD_KEY + topic.getValue().getId();
//
//            String s = jedisPool.getResource().get(key);
//            topic.getValue().setUpIds(s);
//            map.replace(key, topic.getValue());
//        }

        return invocation.proceed();
    }

    @Override
    public Object plugin(Object o) {
        return Plugin.wrap(o, this);
    }

    @Override
    public void setProperties(Properties properties) {

    }
}

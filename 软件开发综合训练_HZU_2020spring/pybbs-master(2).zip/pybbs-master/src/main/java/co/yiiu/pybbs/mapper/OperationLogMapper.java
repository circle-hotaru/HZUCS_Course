package co.yiiu.pybbs.mapper;

import co.yiiu.pybbs.model.OperationLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface OperationLogMapper extends BaseMapper<OperationLog> {
}

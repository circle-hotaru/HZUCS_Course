package co.yiiu.pybbs.controller.api;

import co.yiiu.pybbs.model.OAuthUser;
import co.yiiu.pybbs.model.User;
import co.yiiu.pybbs.service.*;
import co.yiiu.pybbs.service.impl.UserService;
import co.yiiu.pybbs.util.MyPage;
import co.yiiu.pybbs.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


@RestController
@RequestMapping("/api/user")
public class UserApiController extends BaseApiController {

    @Autowired
    private IUserService userService;
    @Autowired
    private ITopicService topicService;
    @Autowired
    private ICommentService commentService;
    @Autowired
    private ICollectService collectService;
    @Autowired
    private IOAuthUserService oAuthUserService;

    // 用户的个人信息
    @GetMapping("/{username}")
    public Result profile(@PathVariable String username) {
        // 查询用户个人信息
        User user = userService.selectByUsername(username);
        // 查询oauth登录的用户信息
        List<OAuthUser> oAuthUsers = oAuthUserService.selectByUserId(user.getId());
        // 查询用户的话题
        MyPage<Map<String, Object>> topics = topicService.selectByUserId(user.getId(), 1, 10);
        // 查询用户参与的评论
        MyPage<Map<String, Object>> comments = commentService.selectByUserId(user.getId(), 1, 10);
        // 查询用户收藏的话题数
        Integer collectCount = collectService.countByUserId(user.getId());

        Map<String, Object> map = new HashMap<>();
        map.put("user", user);
        map.put("oAuthUsers", oAuthUsers);
        map.put("topics", topics);
        map.put("comments", comments);
        map.put("collectCount", collectCount);
        return success(map);
    }

    // 用户发布的话题
    @GetMapping("/{username}/topics")
    public Result topics(@PathVariable String username, @RequestParam(defaultValue = "1") Integer pageNo) {
        // 查询用户个人信息
        User user = userService.selectByUsername(username);
        // 查询用户的话题
        MyPage<Map<String, Object>> topics = topicService.selectByUserId(user.getId(), pageNo, null);
        Map<String, Object> map = new HashMap<>();
        map.put("user", user);
        map.put("topics", topics);
        return success(map);
    }

    // 用户评论列表
    @GetMapping("/{username}/comments")
    public Result comments(@PathVariable String username, @RequestParam(defaultValue = "1") Integer pageNo) {
        // 查询用户个人信息
        User user = userService.selectByUsername(username);
        // 查询用户参与的评论
        MyPage<Map<String, Object>> comments = commentService.selectByUserId(user.getId(), pageNo, null);
        Map<String, Object> map = new HashMap<>();
        map.put("user", user);
        map.put("comments", comments);
        return success(map);
    }

    // 用户收藏的话题
    @GetMapping("/{username}/collects")
    public Result collects(@PathVariable String username, @RequestParam(defaultValue = "1") Integer pageNo) {
        // 查询用户个人信息
        User user = userService.selectByUsername(username);
        // 查询用户参与的评论
        MyPage<Map<String, Object>> collects = collectService.selectByUserId(user.getId(), pageNo, null);
        Map<String, Object> map = new HashMap<>();
        map.put("user", user);
        map.put("collects", collects);
        return success(map);
    }

    // 用户关注的人
    @GetMapping("/{username}/followers")
    public Result followers(@PathVariable String username){
        User user = userService.selectByUsername(username);
        Set<Object> followers = userService.getFollowers(user);
        return success(followers);
    }

    @GetMapping("/{username}/follownum")
    public Result followSize(@PathVariable String username){
        User user = userService.selectByUsername(username);
        int num = userService.getFollowNum(user);
        return success(num);
    }

    @GetMapping("/{username}/fansnum")
    public Result FansSize(@PathVariable String username){
        User user = userService.selectByUsername(username);
        int num = userService.getFunsNum(user);
        return success(num);
    }


    // 用户关注的人
    @GetMapping("/{username}/fans")
    public Result fans(@PathVariable String username){
        User user = userService.selectByUsername(username);
        Set<Object> fans = userService.getFans(user);
        return success(fans);
    }

    // 用户关注的人,需传入关注者跟被关注者，测试用
    @PostMapping("/follow")
    public Result follow(@RequestParam String username1, @RequestParam String username2, HttpServletRequest request){
        User user1 = userService.selectByUsername(username1);
        User user2 = userService.selectByUsername(username2);
        userService.setFollower(user1, user2);
        return success();
    }

    // 用户关注的人
    @PostMapping("/{username}/follow")
    public Result followUser(@PathVariable String username, HttpServletRequest request){
        HttpSession session = request.getSession();
        User user1 = (User)session.getAttribute("_user");
        User user2 = userService.selectByUsername(username);
        userService.setFollower(user1, user2);
        return success();
    }


    @GetMapping("/{username}/isfollow")
    public Result isFollow(@PathVariable String username, HttpServletRequest request){
        HttpSession session = request.getSession();
        User user = (User)session.getAttribute("_user");
        User follow = userService.selectByUsername(username);
        boolean isFollow = userService.isFollow(user, follow);
        return success(isFollow);
    }

}

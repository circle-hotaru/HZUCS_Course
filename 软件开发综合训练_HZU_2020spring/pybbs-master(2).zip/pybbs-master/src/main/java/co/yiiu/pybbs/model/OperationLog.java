package co.yiiu.pybbs.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;

import java.util.Date;

public class OperationLog {
    @TableId(type = IdType.AUTO)
    private Integer logId;
    private  Integer uid;
    private  String content;
    private Date inTime;
    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getLogId() {
        return logId;
    }

    public void setLogId(Integer logId) {
        this.logId = logId;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getInTime() {
        return inTime;
    }

    public void setInTime(Date inTime) {
        this.inTime = inTime;
    }

    @Override
    public String toString() {
        return "OperationLog{" +
                "logId=" + logId +
                ", uid=" + uid +
                ", content='" + content + '\'' +
                ", inTime=" + inTime +
                ", type='" + type + '\'' +
                '}';
    }
}

package co.yiiu.pybbs.service.impl;

import co.yiiu.pybbs.mapper.OperationLogMapper;
import co.yiiu.pybbs.model.OperationLog;
import co.yiiu.pybbs.model.UserLoginLog;
import co.yiiu.pybbs.service.IOperationService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OperationService implements IOperationService {

    @Autowired
    OperationLogMapper operationMapper;

    @Override
    public void insert(OperationLog operationLog) {
        operationMapper.insert(operationLog);
    }

    @Override
    public void deleteById(Integer id) {
        operationMapper.deleteById(id);
    }

    @Override
    public OperationLog selectById(Integer id) {
        return operationMapper.selectById(id);
    }

    @Override
    public List<OperationLog> selectByUserId(Integer userId) {
        return operationMapper.selectList(new QueryWrapper<OperationLog>().eq("uid", userId));
    }

    @Override
    public List<OperationLog> selectAll() {
        return operationMapper.selectList(new QueryWrapper<OperationLog>());
    }


}

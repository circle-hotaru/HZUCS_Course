package co.yiiu.pybbs.model;

public interface ModelInterface {
    Integer getId();
    Integer getUserId();
}

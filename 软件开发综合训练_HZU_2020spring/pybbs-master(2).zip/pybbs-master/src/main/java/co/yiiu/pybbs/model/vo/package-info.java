/**
 * Created by tomoya.
 * Copyright (c) 2018, All Rights Reserved.
 * https://yiiu.co
 */
package co.yiiu.pybbs.model.vo;

/**
 * 这里放的是一些Map转json后，再转回Map出现问题的类，用作确定数据类型的，没有其它实际意义
 */

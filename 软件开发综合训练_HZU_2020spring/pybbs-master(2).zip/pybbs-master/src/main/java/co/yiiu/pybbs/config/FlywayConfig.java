package co.yiiu.pybbs.config;

import co.yiiu.pybbs.controller.admin.SensitiveWordAdminController;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.FlywayException;
import org.flywaydb.core.api.configuration.FluentConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;


@Configuration
public class FlywayConfig {

    @Autowired
    private DataSource dataSource;

    private Logger log = LoggerFactory.getLogger(FlywayConfig.class);

    @PostConstruct
    @DependsOn("dataSourceHelper")
    public void migrate() {
        Flyway flyway = getFlyway();
//        flyway.migrate();
        try{
            flyway.migrate();
        }catch (FlywayException e){
            log.info("数据已经迁移过了");
        }
    }

    @DependsOn("dataSourceHelper")
    public Flyway getFlyway(){
        return Flyway.configure()
                .dataSource(dataSource)
                .locations("classpath:db/migration",
                        "filesystem:db/migration").
                        baselineOnMigrate(true).load();
    }


}

package co.yiiu.pybbs.interceptor;


import co.yiiu.pybbs.mapper.UserLoginLogMapper;
import co.yiiu.pybbs.model.User;
import co.yiiu.pybbs.model.UserLoginLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Date;

@Component
public class LoginLogInterceptor implements HandlerInterceptor {

    @Autowired
    UserLoginLogMapper userLoginLogMapper;
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if(request.getRequestURI().contains("/logout")){
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("_user");
            UserLoginLog userLoginLog = new UserLoginLog();
            userLoginLog.setUid(user.getId());
            userLoginLog.setLogoutTime(new Date());
            userLoginLogMapper.insert(userLoginLog);
        }
        return true;
    }


    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable ModelAndView modelAndView) throws Exception {
            // 不能在这里拦截logout，因为此时session里的user已被清空
            if(request.getRequestURI().contains("/api/login")){
                HttpSession session = request.getSession();
                User user = (User) session.getAttribute("_user");
                UserLoginLog userLoginLog = new UserLoginLog();
                userLoginLog.setUid(user.getId());
                userLoginLog.setLoginTime(new Date());
                userLoginLogMapper.insert(userLoginLog);
            }

//            else if(request.getRequestURI().equals("/api/logout")){
//                System.out.println("request = " + request);
//            }
    }
}

package co.yiiu.pybbs.service;

import co.yiiu.pybbs.model.UserLoginLog;

import java.util.List;

public interface IUserLoginLogService {
    void insert(UserLoginLog userLoginLog);
    void deleteById(Integer id);
    UserLoginLog selectById(Integer id);
    List<UserLoginLog> selectByUserId(Integer uid);
    UserLoginLog selectEndOne(Integer uid);
    UserLoginLog updateEndOne(UserLoginLog userLoginLog);
    List<UserLoginLog> selectAllUserEnd();
    List<UserLoginLog> selectAll();
}

package co.yiiu.pybbs.mapper;

import co.yiiu.pybbs.model.SensitiveWord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * Created by tomoya.
 * Copyright (c) 2018, All Rights Reserved.
 * https://yiiu.co
 */
public interface SensitiveWordMapper extends BaseMapper<SensitiveWord> {
}

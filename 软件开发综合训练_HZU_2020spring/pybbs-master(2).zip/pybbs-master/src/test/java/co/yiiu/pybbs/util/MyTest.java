package co.yiiu.pybbs.util;

import java.io.*;

public class MyTest {
    public static void main(String[] args) throws IOException {
        File file = new File("D:\\Users\\Desktop\\log_warn(1).log");
        FileReader reader = new FileReader(file);
//        char[] content = new char[1024];
//        reader.read(content);
//        System.out.println(String.valueOf(content));

        FileInputStream inputStream = new FileInputStream(file);
        byte[] content = new byte[1024];
        inputStream.read(content);
        System.out.println("content = " + new String(content));
    }
}

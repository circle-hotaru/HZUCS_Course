package co.yiiu.pybbs;

import co.yiiu.pybbs.mapper.OperationLogMapper;
import co.yiiu.pybbs.mapper.UserLoginLogMapper;
import co.yiiu.pybbs.service.impl.OperationService;
import co.yiiu.pybbs.service.impl.UserLoginLogService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PybbsApplicationTests {

//    @Autowired
//    RedisService redisService;
//
//    @Autowired
//    TopicMapper topicMapper;


    @Test
    public void contextLoads() {
//        RedisService redisService = new RedisService();
//        redisService.addSet("abcd", "abcde");
//        redisService.addSet("abcd", "abc");
//        User user = new User();
//        user.setUsername("小明");
//
//        redisService.addSet("user", user);
//        User user1 = new User();
//        user1.setUsername("aaa");
//        redisService.addSet("user", user1);
//        System.out.println("redisService.getSet(\"user\") = " + redisService.getSet("user"));
//        System.out.println("redisService.SetSize(\"user\") = " + redisService.SetSize("user"));
//        System.out.println("redisService.isExistSet(\"user\", user) = " + redisService.isExistSet("user", user));
//        redisService.remSet("user", user);
//        System.out.println("redisService.isExistSet(\"user\", user) = " + redisService.isExistSet("user", user));
//        System.out.println("redisService.getSet(\"abc\") = " + redisService.getSet("abc"));
//        System.out.println("redisService.isExistSet(\"abc\") = " + redisService.isExistSet("abc", "abc"));
//
//        System.out.println("redisService.SetSize(\"abc\") = " + redisService.SetSize("abc"));
//        redisService.remSet("abc", "abc");
//        System.out.println("redisService.isExistSet(\"abc\") = " + redisService.isExistSet("abc", "abc"));
//        System.out.println("redisService.instance() = " + redisService.instance());
//        redisService.setString("aaa", "abc", 10000);
    }


    @Test
    public void test1() throws IOException {
        File file = new File("D:\\Users\\Desktop\\log_warn(1).log");
        FileReader reader = new FileReader(file);
        char[] content = new char[1024];
        reader.read(content);
        System.out.println("content = " + String.valueOf(content));

//        System.out.println("topicMapper.selectById(1) = " + topicMapper.selectById(1));
    }

    @Autowired
    UserLoginLogMapper userLoginLogMapper;

    @Autowired
    OperationLogMapper operationLogMapper;

    @Autowired
    OperationService operationService;

    @Autowired
    UserLoginLogService userLoginLogService;

    @Test
    public void test2(){
//        userLoginLogService.selectEndOne(1);
        userLoginLogService.selectAllUserEnd().forEach((item) ->
                System.out.println("item = " + item));
//        operationService.selectByUserId(1).forEach((item) ->{
//            System.out.println("item = " + item);
//        });
//        UserLoginLog userLoginLog = new UserLoginLog();
//        userLoginLog.setUid(1);
//        userLoginLog.setLoginTime(new Date());
//        userLoginLogMapper.insert(userLoginLog);
//        OperationLog operationLog = new OperationLog();
//        operationLog.setContent("abcd");
//        operationLogMapper.insert(operationLog);
    }
}
